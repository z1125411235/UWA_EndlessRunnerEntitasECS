﻿using System;
using System.Collections.Generic;

[Serializable]
public class ChunkDefinitions
{
    public List<ChunkDefinition> Definitions;
}