﻿using System;

[Serializable]
public class ChunkDefinition
{
    public string Asset = "...";
    public float Width = 0f;
}