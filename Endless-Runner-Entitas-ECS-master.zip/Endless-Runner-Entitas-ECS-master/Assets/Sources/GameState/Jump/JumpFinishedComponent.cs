﻿using Entitas;
using Entitas.CodeGeneration.Attributes;

[GameState]
[Unique]
public sealed class JumpFinishedComponent : IComponent
{
}