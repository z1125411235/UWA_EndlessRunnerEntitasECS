﻿using Entitas;
using Entitas.CodeGeneration.Attributes;

[GameState]
[Unique]
public sealed class JumpingComponent : IComponent
{
}