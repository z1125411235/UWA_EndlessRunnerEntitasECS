﻿public class Services
{
    public CreatePlayerService CreatePlayerService;
    public CreateChunkService  CreateChunkService;
    public KillPlayerService   KillPlayerService;
    public IdService           IdService;
    public IInputService       InputService;

    public JumpService  JumpService;
    public ITimeService TimeService;

    public IViewService ViewService;
    public IPhysicsService PhysicsService;
    public ICollisionEmisstionService CollisionEmisstionService;
}