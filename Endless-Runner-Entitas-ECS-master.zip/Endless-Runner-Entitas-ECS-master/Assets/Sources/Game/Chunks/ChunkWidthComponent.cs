﻿using Entitas;

[Game]
public sealed class ChunkWidthComponent : IComponent
{
    public float Value;
}