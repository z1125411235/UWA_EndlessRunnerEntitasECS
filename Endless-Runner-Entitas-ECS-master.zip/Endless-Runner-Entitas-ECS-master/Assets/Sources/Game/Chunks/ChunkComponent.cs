﻿using Entitas;

[Game]
public sealed class ChunkComponent : IComponent
{
}