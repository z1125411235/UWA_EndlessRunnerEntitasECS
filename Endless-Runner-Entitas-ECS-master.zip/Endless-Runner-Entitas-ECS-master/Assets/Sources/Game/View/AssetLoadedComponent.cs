﻿using Entitas;

[Game]
public sealed class AssetLoadedComponent : IComponent
{
}