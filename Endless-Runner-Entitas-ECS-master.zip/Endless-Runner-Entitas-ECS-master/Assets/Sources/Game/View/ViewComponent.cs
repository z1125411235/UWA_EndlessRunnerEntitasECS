﻿using Entitas;

[Game]
public sealed class ViewComponent : IComponent
{
    public IView Value;
}