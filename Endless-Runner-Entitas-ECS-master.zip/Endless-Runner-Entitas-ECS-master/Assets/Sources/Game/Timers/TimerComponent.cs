﻿using Entitas;

[Game]
public sealed class TimerComponent : IComponent
{
    public float Value;
}