﻿using Entitas;

[Game]
public sealed class RespawnComponent : IComponent
{
}