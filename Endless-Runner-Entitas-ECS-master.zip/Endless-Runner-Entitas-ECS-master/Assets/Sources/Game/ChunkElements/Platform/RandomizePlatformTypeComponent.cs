﻿using Entitas;

[Game]
public sealed class RandomizePlatformTypeComponent : IComponent
{
}