﻿using Entitas;

[Game]
public sealed class PlatformComponent : IComponent {}