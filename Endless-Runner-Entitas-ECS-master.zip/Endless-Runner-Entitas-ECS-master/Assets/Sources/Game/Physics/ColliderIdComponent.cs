﻿using Entitas;

[Game]
public sealed class ColliderIdComponent : IComponent
{
    public int Value;
}