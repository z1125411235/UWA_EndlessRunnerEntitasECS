﻿using Entitas;

[Game]
public sealed class CollisionComponent : IComponent
{
}