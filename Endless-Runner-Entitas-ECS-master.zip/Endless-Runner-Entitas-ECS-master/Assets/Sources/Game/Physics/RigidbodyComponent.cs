﻿using Entitas;

[Game]
public sealed class RigidbodyComponent : IComponent
{
    public IRigidbody Value;
}