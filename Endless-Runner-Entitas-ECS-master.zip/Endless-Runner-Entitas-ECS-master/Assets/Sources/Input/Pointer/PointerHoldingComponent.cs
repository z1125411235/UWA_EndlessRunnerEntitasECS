﻿using Entitas;
using Entitas.CodeGeneration.Attributes;

[Input]
public sealed class PointerHoldingComponent : IComponent
{
}