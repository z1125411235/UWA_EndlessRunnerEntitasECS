﻿using Entitas;
using Entitas.CodeGeneration.Attributes;

[Input]
public sealed class PointerHoldingTimeComponent : IComponent
{
    public float value;
}